package restaurantsystem.component.auth;

import javax.swing.*;

public class itemMana {
    private JTextField thisIsCrazyTextField;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JRadioButton radioButton1;
    private JButton button1;
}
